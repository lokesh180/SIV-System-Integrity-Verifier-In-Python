#!/usr/bin/env python3
from argparse import ArgumentParser
from Initialization import initialization
from Verification import verification

def main():

    argument_parser = ArgumentParser()
    groupofargs = argument_parser.add_mutually_exclusive_group()
    groupofargs.add_argument("-i", "--initmode", action="store_true",help="Initialization Mode.")
    groupofargs.add_argument("-v", "--verifymode", action="store_true",help="Verification Mode.")
    argument_parser.add_argument("-D", "--Directory",type=str, help="Given directory is monitored.")
    argument_parser.add_argument("-V", "--Verification_file", type=str,help="The verification data will be stored in this file but should be out of monitered directory.")
    argument_parser.add_argument("-R", "--Report_file", type=str,help="The report will be stored in this file and should be out of monitered directory as well.")
    argument_parser.add_argument("-H", "--Hash_function", type=str,help="Use the Hash function as md5 or sha1.")
    arguments = argument_parser.parse_args()

    if arguments.initmode and arguments.Directory and arguments.Verification_file and arguments.Report_file and arguments.Hash_function:
        initialization(arguments)

    elif arguments.verifymode and arguments.Directory and arguments.Verification_file and arguments.Report_file and not arguments.Hash_function:
        verification(arguments)
    else:
        print("---The Given Format is Wrong---")
        #print("-h,     ->       Help Message Displayed.\n")
        print(" For Initalization mode:\nusage: ./siv -i [-D Monitered_Directory] [-V Verification_file] [-R Report_file] [-H Hash_function]")
        print(" For Verification mode:\nusage: ./siv -i [-D Monitered_Directory] [-V Verification_file] [-R Report_file]")
        print("Try using python3 siv.py -h for all options")


if __name__ == "__main__":
    main()