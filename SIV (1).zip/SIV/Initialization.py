import os
import sys
import stat
import hashlib
import time
import json

from required_functions import isdirexist, creating_files, get_information

def initialization(arguments):
    file_counter = 0
    directory_counter = 0
    json_file = ""
    file_info = {}
    message_digest = ""

    if not isdirexist(arguments.Directory):
        sys.exit()

    creating_files(arguments.Directory,arguments.Verification_file, arguments.Report_file,"i")
 
    if arguments.Hash_function not in ["sha1", "md5"]:
        print("allowed values for hashing are sha1 and md5 (case sensitive)\n")
        sys.exit()
        
    start = time.time()  # recording initialization time start
    for subdir, dirs, files in os.walk(arguments.Directory):
        for filename in files:
            file_path = subdir + os.sep + filename
            size,owner,group,permission,last_modified = get_information(file_path)
            # set digest to specified hash method
            if arguments.Hash_function in ["sha1"]:
                hashing_func = hashlib.sha1()
                with open(file_path, 'rb') as afile:
                    buf = afile.read()
                    hashing_func.update(buf)
                    message_digest = hashing_func.hexdigest()

            if arguments.Hash_function in ["md5"]:
                hashing_func = hashlib.md5()
                with open(file_path, 'rb') as afile:
                    buf = afile.read()
                    hashing_func.update(buf)
                    message_digest = hashing_func.hexdigest()

            file_info[file_path] = {"Full path to file/directory": file_path,
                                        "Size of the file": size,
                                        "Name of user owning the file/directory": owner,
                                        "Name of group owning the file/directory": group,
                                        "Access rights to the file/directory (symbolic)": permission,
                                        "Last modification date": last_modified,
                                        "Computed message digest with": message_digest,
                                        "specified hash function over file contents": arguments.Hash_function}

            file_counter = file_counter+1
            json_file = json.dumps(file_info, indent=4)

        for dir in dirs:
            directory_path = subdir + os.sep + dir
            size,owner,group,permission,last_modified = get_information(directory_path)

            file_info[directory_path] = {"Full path to file/directory": directory_path,
                                            "Size of the file": size,
                                            "Name of user owning the file/directory": owner,
                                            "Name of group owning the file/directory": group,
                                            "Access rights to the file/directory (symbolic)": permission,
                                            "Last modification date": last_modified}

            directory_counter = directory_counter+1
            json_file = json.dumps(file_info, indent=4)

    end = time.time()   # recording initialization time end
    with open(arguments.Verification_file,  "w") as the_file:
        the_file.write(json_file)
        print("Verification file generated\n")

    jsonified_report = json.dumps({"Full path of monitored directory": arguments.Directory,
                                    "Full pathname to verification file": os.path.abspath(arguments.Verification_file) ,
                                    "Number of directories traversed": directory_counter,
                                    "Number of files traversed": file_counter,
                                    "Time to complete the initialization mode": (end-start)*1000}, indent=4)

    with open(arguments.Report_file, "w") as the_file:
        the_file.write(jsonified_report)
        print("Report file generated\n")
        print("Initialization mode completed\n")
