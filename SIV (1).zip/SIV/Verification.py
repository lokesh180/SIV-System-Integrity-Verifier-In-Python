"""
"""
import os
import json
import time
from pwd import getpwuid
from grp import getgrgid
import sys
import stat
import hashlib
from required_functions import isdirexist, creating_files, get_information

def verification(arguments):
    file_counter = 0
    directory_counter = 0
    changes = 0
    message_digest = ""

    isdirexist(arguments.Directory)


    creating_files(arguments.Directory,arguments.Verification_file,arguments.Report_file,"v")

    with open(arguments.Verification_file) as verificationfile:
        verification_json = json.load(verificationfile)

    with open(arguments.Report_file, "w") as the_file:
        start = time.time()  
        for subdir, dirs, files in os.walk(arguments.Directory):
            for filename in files:
                file_path = subdir + os.sep + filename
                size,owner,group,permission,last_modified = get_information(file_path)


                if file_path in verification_json.keys():

                    if size != verification_json[file_path]["Size of the file"]:
                        the_file.write(
                            "\nIntegrity Change Detected : The file " + file_path + " size has changed\n")
                        changes = changes+1
                    if owner != verification_json[file_path]["Name of user owning the file/directory"]:
                        the_file.write(
                            "\nIntegrity Change Detected : The owner of file " + file_path + " has been changed\n")
                        changes = changes+1
                    if group != verification_json[file_path]["Name of group owning the file/directory"]:
                        the_file.write(
                            "\nIntegrity Change Detected : The group of file " + file_path + " has been changed\n")
                        changes = changes+1
                    if permission != verification_json[file_path]["Access rights to the file/directory (symbolic)"]:
                        the_file.write(
                            "\nIntegrity Change Detected :" + file_path + " has different accesss rights\n")
                        changes = changes+1
                    if last_modified != verification_json[file_path]["Last modification date"]:
                        the_file.write("\nIntegrity Change Detected :" +
                                    file_path + " has different last modified date\n")
                        changes = changes+1

                    hash_type = verification_json[file_path]["specified hash function over file contents"]

                    
                    if hash_type in ["sha1"]:
                        hashing_func = hashlib.sha1()
                        with open(file_path, 'rb') as afile:
                            buffer = afile.read()
                            hashing_func.update(buffer)
                            message_digest = hashing_func.hexdigest()
                            if message_digest != verification_json[file_path]["Computed message digest with"]:
                                the_file.write(
                                    "\nIntegrity Change Detected :" + file_path + " has different message digest\n")
                                changes = changes+1

                    if hash_type in ["md5"]:
                        hashing_func = hashlib.md5()
                        with open(file_path, 'rb') as afile:
                            buffer = afile.read()
                            hashing_func.update(buffer)
                            message_digest = hashing_func.hexdigest()
                            if message_digest != verification_json[file_path]["Computed message digest with"]:
                                the_file.write(
                                    "\nIntegrity Change Detected :" + file_path + " has different message digest\n")
                                changes = changes+1
                else:
                    the_file.write("\nIntegrity Change Detected :" +
                                file_path + " has been added to monitoring directory\n")
                    changes = changes+1
                file_counter = file_counter+1

            for dir in dirs:
                    
                directory_path = subdir + os.sep + dir
                size,owner,group,permission,last_modified = get_information(directory_path)

                if directory_path in verification_json.keys():
                    if size != verification_json[directory_path]["Size of the file"]:
                        the_file.write(
                            "\nIntegrity Change Detected : The directory " + directory_path + " has different size\n")
                        changes = changes+1
                    if owner != verification_json[directory_path]["Name of user owning the file/directory"]:
                        the_file.write(
                            "\nIntegrity Change Detected : The owner of file " + directory_path + " has been changed\n")
                        changes = changes+1
                    if group != verification_json[directory_path]["Name of group owning the file/directory"]:
                        the_file.write(
                            "\nIntegrity Change Detected : The group of file " + directory_path + " has been changed\n")
                        changes = changes+1
                    if permission != verification_json[directory_path]["Access rights to the file/directory (symbolic)"]:
                        the_file.write("\nIntegrity Change Detected :" +
                                    directory_path + " has different accesss rights\n")
                        changes = changes+1
                    if last_modified != verification_json[directory_path]["Last modification date"]:
                        the_file.write("\nIntegrity Change Detected :" +
                                    directory_path + " has different last modified date\n")
                        changes = changes+1
                else:
                    the_file.write(
                        "\nIntegrity Change Detected :" + file_path + " has been added\n")
                directory_counter = directory_counter+1

        for node in verification_json.keys():
            if os.path.exists(node) == 0:
                the_file.write("\nIntegrity Change Detected : " + node + " has been deleted\n")
                changes = changes+1
    end = time.time()  

    jsonified_report = json.dumps({"Full path of monitored directory": arguments.Directory,
                                    "Full pathname to verification file": os.path.abspath(arguments.Verification_file),
                                    "Number of directories traversed": directory_counter,
                                    "Number of files traversed": file_counter,
                                    "Time to complete the verification mode": (end-start)*1000,
                                    "Number of changes detected": changes}, indent=4)

    with open(arguments.Report_file, "a") as final_report:
        final_report.write(jsonified_report)
        print("Verification mode completed\n")
