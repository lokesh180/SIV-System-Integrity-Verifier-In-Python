"""
"""
import os
import sys
import stat
import time
from pwd import getpwuid
from grp import getgrgid

def isdirexist(monitored_directory):
    if os.path.exists(monitored_directory):
        print("Directory Exists\n")
        return True
    else:
        print("Directory does not exist. Specify an existing directory or create it.\n")
    return False

def creating_files(monitored_directory,verification_db,report_file,mode):
    if os.getcwd() == monitored_directory:
        print('Please Stay outside the monitoring directory')
        sys.exit()
    elif monitored_directory == verification_db.split('/')[0]:
        print('Please Make use of a VerificationDB outside of monitoring directory')
        sys.exit()
    elif monitored_directory == report_file.split('/')[0]:
        print('Please Make Report file outside of monitoring directory')
        sys.exit()
    
    else:
        if mode == "i":
            if os.path.exists(verification_db):
                print("Overwrite Existing Verification DB\n")
                os.open(verification_db, os.O_CREAT, mode=0o0777)
            else:
                os.open(verification_db, os.O_CREAT, mode=0o0777)
                print("Created Verification DB\n")

            if os.path.exists(report_file):
                print("Report file exist\n")
            else:
                print("Creating Report file\n")
                os.open(report_file, os.O_CREAT, mode=0o0777)
                    
        if mode == "v":
            if os.path.exists(verification_db):
                print("Using information from Existing Verification DB\n")
            else:
                
                print("Please create a verificationDB first\n")
                sys.exit()

            if os.path.exists(report_file):
                print("Report file exist, overwriting contents\n")
                os.open(report_file, os.O_CREAT, mode=0o0777)
            else:
                print("Creating Report file\n")
                os.open(report_file, os.O_CREAT, mode=0o0777)

def get_information(path):
    """
    FYI :  
    getpwuid(os.stat(file_path).st_uid).pw_name
    the st_uid of a file is the user id that exists in /etc/passwd
    It is a number like , say 1000. the getpwuid returns a struct from /etc/passwd corressponding to uid.
    We just need the name or pw_name attribute. Can't believe easier alterantives to my original plan existed lol
    (Danke schon stack overflow)
    same for group.
    """
    st = os.stat(path)
    size = os.path.getsize(path)
    owner = getpwuid(os.stat(path).st_uid).pw_name
    group = getgrgid(os.stat(path).st_gid).gr_name
    permission = stat.filemode(st.st_mode)
    last_modified = time.ctime(os.path.getmtime(path))
    return size,owner,group,permission,last_modified